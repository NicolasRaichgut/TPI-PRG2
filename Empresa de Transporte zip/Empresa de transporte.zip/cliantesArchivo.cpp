#include <iostream>
#include "clientesArchivo.h"
using namespace std;

bool ClientesArchivo::guardarArchivo(Clientes obj){
    FILE *pCl;

    pCl=fopen(nombre, "ab");
    if(pCl==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }
    bool archivoCargado=fwrite(&obj, sizeof obj, 1, pCl);
    fclose(pCl);
    return archivoCargado;
}
Clientes ClientesArchivo::leerArchivo(int indice){
    FILE *pCl;
    Clientes cliente;

    pCl=fopen(nombre, "rb");
    if(pCl==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return cliente;
    }
    fseek(pCl, indice*sizeof cliente, 0);
    fread(&cliente, sizeof cliente, 1, pCl);
    fclose(pCl);
    return cliente;
}
int ClientesArchivo::contarRegistros(){
    FILE *pCl;
    Clientes cliente;

    pCl=fopen(nombre, "rb");
    if(pCl==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return 0;
    }
    fseek(pCl, 0, SEEK_END);
    int bytes=ftell(pCl);

    return bytes/sizeof cliente;
}
