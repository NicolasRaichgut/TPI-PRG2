#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include "choferes.h"
using namespace std;

Choferes::Choferes(){
    DNI[0]='0';
    nombre[0]='NN';
    apellido[0]='NN';
    numTelefono[0]='0';
    email[0]='NN';
    direccion[0]='NN';
    Fecha f;
    fechaNacimiento=f;
}
Choferes::Choferes(string _DNI, string _nombre, string _apellido, string _numTelefono, string _email, string _direccion, Fecha _fechaNacimiento){
    setDNI(_DNI);
    setNombre(_nombre);
    setApellido(_apellido);
    setNumTelefono(_numTelefono);
    setEmail(_email);
    setDireccion(_direccion);
    setFechaNacimiento(_fechaNacimiento);
}

void Choferes::setDNI(string d){
    strcpy(DNI, d.c_str());
}
void Choferes::setNombre(string n){
    strcpy(nombre, n.c_str());
}
void Choferes::setApellido(string a){
    strcpy(apellido, a.c_str());
}
void Choferes::setNumTelefono(string t){
    strcpy(numTelefono, t.c_str());
}
void Choferes::setEmail(string e){
    strcpy(email, e.c_str());
}
void Choferes::setDireccion(string d){
    strcpy(direccion, d.c_str());
}
void Choferes::setFechaNacimiento(Fecha f){
    fechaNacimiento=f;
}

void Choferes::setEliminado(bool el){
    eliminado=el;
}

char* Choferes::getDNI() {
    return DNI;
}

char* Choferes::getNombre() {
    return nombre;
}

char* Choferes::getApellido() {
    return apellido;
}

char* Choferes::getNumTelefono() {
    return numTelefono;
}

char* Choferes::getEmail() {
    return email;
}

char* Choferes::getDireccion() {
    return direccion;
}

Fecha Choferes::getFechaNacimiento() {
    return fechaNacimiento;
}
bool Choferes::getEliminado(){
    return eliminado;
}

void Choferes::cargarChofer(){
    cout<<"Ingrese su DNI: ";
    string d;
    cin>>d;
    setDNI(d);
    cout<<endl;
    cout<<"Ingrese su nombre: ";
    string n;
    cin>>n;
    setNombre(n);
    cout<<endl;
    cout<<"Ingrese su apellido: ";
    string a;
    cin>>a;
    setApellido(a);
    cout<<endl;
    cout<<"Ingrese su numero telefonico(9/11 ****-****): ";
    string t;
    cin>>t;
    setNumTelefono(t);
    cout<<endl;
    cout<<"Ingrese su email: ";
    string e;
    cin>>e;
    setEmail(e);
    cout<<endl;
    cout<<"Ingrese su direccion: ";
    string drec;
    cin>>drec;
    setDireccion(drec);
    cout<<endl;
    cout<<"Ingrese su fecha de nacimiento: ";
    int dia;
    cin>>dia;
    cout<<"/";
    int mes;
    cin>>mes;
    cout<<"/";
    int an;
    cin>>an;
    Fecha f(dia,mes,an);
    setFechaNacimiento(f);
    cout<<endl;
}

void Choferes::mostrarChofer(){
    cout<<nombre<<" "<<apellido<<endl;
    cout<<"----------------------------------------------------"<<endl;
    cout<<"DNI: "<<DNI<<endl;
    cout<<"Numero telefonico: "<<numTelefono<<endl;
    cout<<"Email: "<<email<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"Fecha de nacimiento: ";
    fechaNacimiento.mostrar();
    cout<<endl;
    cout<<"Patente: "<<patente<<endl;
    cout<<"-----------------------------------------------------"<<endl;
}
