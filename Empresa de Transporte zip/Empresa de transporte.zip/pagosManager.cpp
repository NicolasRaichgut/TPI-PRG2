#include <iostream>
#include <cstring>
#include "pagosManager.h"
using namespace std;

bool PagosManager::existeIdViaje(char* id){
    Viajes viaje;
    int cantidad=archivoViajes.contarRegistros();

    for(int i=0;i<cantidad;i++){
        viaje=archivoViajes.leerArchivo(i);
        if(strcmp(viaje.getIdViaje(),id)==0){
            return true;
        }
    }

    return false;
}

void PagosManager::crearPago(){
    char idViaje[6];

    cout<<"Ingrese ID del viaje: ";
    cin>>idViaje;
    if(!existeIdViaje(idViaje)){
        cout<<"El viaje no existe."<<endl;
        return;
    }

    pago.cargar(idViaje);
    if(archivo.guardarArchivo(pago)){
        cout<<"Pago guardado correctamente."<<endl;
    }
    else{
        cout<<"No se pudo guardar el pago."<<endl;
    }
}

void PagosManager::listarPagos(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        pago=archivo.leerArchivo(i);
        pago.mostrar();
        if(i!=cantidad-1){
            cout<<"---------------------------"<<endl;
        }
    }
}
