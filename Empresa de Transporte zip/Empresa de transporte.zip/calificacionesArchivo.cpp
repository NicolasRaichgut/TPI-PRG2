#include <iostream>
#include "calificacionesArchivo.h"
using namespace std;

bool CalificacionesArchivo::guardarArchivo(Calificaciones obj){
    FILE *pC;
    pC=fopen(nombre,"ab");

    if(pC==nullptr){
        cout<<"No se pudo crear el archivo."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj,sizeof obj,1,pC);
    fclose(pC);

    return guardado;
}

Calificaciones CalificacionesArchivo::leerArchivo(int indice){
    FILE *pC;
    Calificaciones calificacion;
    pC=fopen(nombre,"rb");

    if(pC==nullptr){
        cout<<"No se pudo abrir el archivo."<<endl;
        return calificacion;
    }

    fseek(pC,indice*sizeof calificacion,0);
    fread(&calificacion,sizeof calificacion,1,pC);
    fclose(pC);

    return calificacion;
}

int CalificacionesArchivo::contarRegistros(){
    FILE *pC;
    Calificaciones calificacion;
    pC=fopen(nombre,"rb");

    if(pC==nullptr){
        return 0;
    }

    fseek(pC,0,SEEK_END);
    int bytes=ftell(pC);
    fclose(pC);

    return bytes/sizeof calificacion;
}
