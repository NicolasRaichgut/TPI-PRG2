#include "menu.h"

Menu::Menu(const char* _titulo, int _cantidadOpciones) {
    strcpy(titulo, _titulo);
    cantidadOpciones = _cantidadOpciones;
}

void Menu::mostrarEncabezado() {
    cout<<endl;
    cout<<"=============================="<<endl;
    cout<<titulo<<endl;
    cout<<"=============================="<<endl;
}

int Menu::pedirOpcion() {
    int opcion;
    cout<<"SELECCION: ";
    cin>>opcion;

    while(opcion<0||opcion>cantidadOpciones) {
        cout<<"Opcion invalida. Reingrese: ";
        cin>>opcion;
    }

    return opcion;
}
