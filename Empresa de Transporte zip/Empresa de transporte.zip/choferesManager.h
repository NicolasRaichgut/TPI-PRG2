#pragma once
#include "choferesArchivo.h"

class ChoferesManager{
private:
    Choferes chofer;
    ChoferesArchivo archivo;
    bool existeElID(char* ID);
public:
    void crearChofer();
    void listarChoferes();
    void buscarChoferXID(char* IDABuscar);
};
