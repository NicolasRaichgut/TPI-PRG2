#include <iostream>
#include "pagosArchivo.h"
using namespace std;

bool PagosArchivo::guardarArchivo(Pagos obj){
    FILE *pP;
    pP=fopen(nombre,"ab");

    if(pP==nullptr){
        cout<<"No se pudo crear el archivo."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj,sizeof obj,1,pP);
    fclose(pP);

    return guardado;
}

Pagos PagosArchivo::leerArchivo(int indice){
    FILE *pP;
    Pagos pago;
    pP=fopen(nombre,"rb");

    if(pP==nullptr){
        cout<<"No se pudo abrir el archivo."<<endl;
        return pago;
    }

    fseek(pP,indice*sizeof pago,0);
    fread(&pago,sizeof pago,1,pP);
    fclose(pP);

    return pago;
}

int PagosArchivo::contarRegistros(){
    FILE *pP;
    Pagos pago;
    pP=fopen(nombre,"rb");

    if(pP==nullptr){
        return 0;
    }

    fseek(pP,0,SEEK_END);
    int bytes=ftell(pP);
    fclose(pP);

    return bytes/sizeof pago;
}
