#include <iostream>
#include <cstring>
#include "viajesManager.h"
using namespace std;

bool ViajesManager::existeCliente(char* dni){
    int cantidad=archivoClientes.contarRegistros();
    Clientes cliente;

    for(int i=0;i<cantidad;i++){
        cliente=archivoClientes.leerArchivo(i);
        if(strcmp(cliente.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}
bool ViajesManager::existeChofer(char* dni){

    int cantidad=archivoChoferes.contarRegistros();
    Choferes chofer;

    for(int i=0;i<cantidad;i++){
        chofer=archivoChoferes.leerArchivo(i);
        if(strcmp(chofer.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}

void ViajesManager::crearViaje(){
    char dniCliente[8];
    char dniChofer[8];

    cout<<"Ingrese el DNI del cliente: ";
    cin>>dniCliente;
    if(!existeCliente(dniCliente)){
        cout<<"Ese DNI no corresponde a ningun cliente."<<endl;
        return;
    }

    cout<<"Ingrese el DNI del chofer: ";
    cin>>dniChofer;
    if(!existeChofer(dniChofer)){
        cout<<"Ese DNI no corresponde a ningun chofer."<<endl;
        return;
    }

    viaje.cargar(dniCliente, dniChofer);

    system("cls");

    if(archivo.guardarArchivo(viaje)){
        cout<<"El viaje fue guardado exitosamente!"<<endl;
    }
    else{
        cout<<"Ups... No se pudo guardar el viaje."<<endl;
    }
}

void ViajesManager::listarViajes(){

    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        viaje=archivo.leerArchivo(i);
        viaje.mostrar();
        if(i!=cantidad-1){
            cout<<"-----------------------------"<<endl;
        }
    }
}

void ViajesManager::buscarViajeXId(char* idABuscar){

    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        viaje=archivo.leerArchivo(i);
        if(strcmp(viaje.getIdViaje(), idABuscar)==0){
                viaje.mostrar();
        }
    }
}
