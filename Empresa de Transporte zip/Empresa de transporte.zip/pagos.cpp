#include <iostream>
#include <cstring>
#include "pagos.h"
using namespace std;

Pagos::Pagos(){

    idPago[0]='\0';
    idViaje[0]='\0';
    metodoPago=0;
    monto=0;
    eliminado=false;
}
Pagos::Pagos(string _idPago, string _idViaje, int _metodoPago, float _monto, Fecha _fechaPago){
    setIdPago(_idPago);
    setIdViaje(_idViaje);
    setMetodoPago(_metodoPago);
    setMonto(_monto);
    setFechaPago(_fechaPago);
    eliminado=false;
}
char* Pagos::getIdPago(){
    return idPago;
}
char* Pagos::getIdViaje(){
    return idViaje;
}
int Pagos::getMetodoPago(){
    return metodoPago;
}
float Pagos::getMonto(){
    return monto;
}
Fecha Pagos::getFechaPago(){
    return fechaPago;
}
bool Pagos::getEliminado(){
    return eliminado;
}
void Pagos::setIdPago(string idP){
    strcpy(idPago, idP.c_str());
}
void Pagos::setIdViaje(string idV){
    strcpy(idViaje, idV.c_str());
}
void Pagos::setMetodoPago(int mp){
    metodoPago=mp;
}
void Pagos::setMonto(float m){
    monto=m;
}
void Pagos::setFechaPago(Fecha fp){
    fechaPago=fp;
}
void Pagos::eliminar(){
    eliminado=true;
}

void Pagos::cargar(char* idV){
    setIdViaje(idV);
    cout<<"Ingrese ID del pago: ";
    string idCarga;
    cin>>idCarga;
    setIdPago(idCarga);
    cout<<"Metodo de pago:"<<endl;
    cout<<"1 - Efectivo"<<endl;
    cout<<"2 - Tarjeta"<<endl;
    cout<<"3 - Transferencia"<<endl;
    int mpCarga;
    cin>>mpCarga;
    setMetodoPago(mpCarga);
    cout<<"Ingrese el monto: ";
    float mCarga;
    cin>>mCarga;
    setMonto(mCarga);
    fechaPago.ponerFechaActual();
}

void Pagos::mostrar(){
    cout<<"ID pago: "<<idPago<<endl;
    cout<<"ID viaje: "<<idViaje<<endl;
    cout<<"Metodo de pago: "<<metodoPago<<endl;
    cout<<"Monto: "<<monto<<endl;
    cout<<"Fecha: ";
    fechaPago.mostrar();
    cout<<endl;
}
