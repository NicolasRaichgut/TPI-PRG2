#pragma once
#include "clientes.h"

class ClientesArchivo{
private:
    const char* nombre="clientes.dat";
public:
    bool guardarArchivo(Clientes obj);
    Clientes leerArchivo(int indice);
    int contarRegistros();
};
