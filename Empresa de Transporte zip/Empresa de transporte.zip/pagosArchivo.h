#pragma once
#include "pagos.h"

class PagosArchivo{
private:
    const char* nombre="pagos.dat";
public:
    bool guardarArchivo(Pagos obj);
    Pagos leerArchivo(int indice);
    int contarRegistros();
};
