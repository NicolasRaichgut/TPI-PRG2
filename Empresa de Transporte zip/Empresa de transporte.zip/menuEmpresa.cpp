#include <iostream>
#include "menuEmpresa.h"
#include "menuClientes.h"
#include "menuChoferes.h"
#include "menuViajes.h"
using namespace std;

MenuEmpresa::MenuEmpresa():Menu("GESTOR DE LA EMPRESA", 4) {}

void MenuEmpresa::mostrarOpciones(){
    cout<<"1. Clientes"<<endl;
    cout<<"2. Choferes"<<endl;
    cout<<"3. Viajes"<<endl;
    cout<<"---------------------------------"<<endl;
    cout<<"0. Salir"<<endl;
    cout<<"---------------------------------"<<endl;
}

void MenuEmpresa::ejecutar(){
    int opcion;
    do{
        mostrarEncabezado();
        mostrarOpciones();
        opcion=pedirOpcion();

        switch(opcion){
            case 1:{
                MenuClientes menu;
                menu.ejecutar();
                break;
            }
            case 2:{
                MenuChoferes menu;
                menu.ejecutar();
                break;
            }
            case 3:{
                MenuViajes menu;
                menu.ejecutar();
                break;
            }
            case 4:
                break;
            case 5:
                break;
        }

    }while(opcion!=0);
}
