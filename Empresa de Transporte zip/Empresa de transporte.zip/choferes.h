#pragma once
#include <string>
#include "fecha.h"
using namespace std;

class Choferes{
private:
    char DNI[8];
    char nombre[20];
    char apellido[20];
    char numTelefono[12];
    char email[50];
    char direccion[50];
    char patente[10];
    Fecha fechaNacimiento;
    bool eliminado=0;
public:
    Choferes();
    Choferes(string _DNI, string _nombre, string _apellido, string _numTelefono, string _email, string _direccion, Fecha _fechaNacimiento);
    void setDNI(string d);
    void setNombre(string n);
    void setApellido(string a);
    void setNumTelefono(string t);
    void setEmail(string e);
    void setDireccion(string d);
    void setFechaNacimiento(Fecha f);
    void setEliminado(bool el);
    char* getDNI();
    char* getNombre();
    char* getApellido();
    char* getNumTelefono();
    char* getEmail();
    char* getDireccion();
    char* getPatente();
    Fecha getFechaNacimiento();
    bool getEliminado();
    void cargarChofer();
    void mostrarChofer();
};
