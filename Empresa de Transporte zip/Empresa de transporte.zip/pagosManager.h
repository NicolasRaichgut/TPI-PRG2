#pragma once
#include "pagosArchivo.h"
#include "viajesArchivo.h"

class PagosManager{
private:
    Pagos pago;
    PagosArchivo archivo;
    ViajesArchivo archivoViajes;

    bool existeIdViaje(char* id);
public:
    void crearPago();
    void listarPagos();
};
