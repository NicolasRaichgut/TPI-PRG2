#pragma once
#include <string>
#include "fecha.h"
using namespace std;

class Remises{
private:
    char patente[10];
    char marca[20];
    char modelo[20];
    char DNIchofer[8];
    Fecha fechaLanzamiento;
    int capacidadPasajeros;
    bool eliminado;
public:
    Remises();
    Remises(string _patente, string _marca, string _modelo, string _DNIchofer, Fecha _fechaLanzamiento, int _capacidadPasajeros);
    void setPatente(string p);
    void setMarca(string m);
    void setModelo(string mo);
    void setDNIchofer(string dni);
    void setFechaLanzamiento(Fecha f);
    void setCapacidadPasajeros(int cp);
    void eliminar();
    char* getPatente();
    char* getMarca();
    char* getModelo();
    char* getDNIchofer();
    Fecha getFechaLanzamiento();
    int getCapacidadPasajeros();
    bool getEliminado();
    void cargar();
    void mostrar();
};
