#include <iostream>
#include <cstring>
#include "clientesManager.h"
using namespace std;

bool ClientesManager::existeElID(char* ID){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(strcmp(cliente.getDNI(), ID)==0){
            return true;
        }
    }

    return false;
}
void ClientesManager::crearCliente(){
    cliente.cargarCliente();
    system("cls");

    if(archivo.guardarArchivo(cliente)){
        cout<<"El cliente fue guardado exitosamente!"<<endl;
    }else{
        cout<<"Ups... No se pudo guardar al cliente."<<endl;
    }
}

void ClientesManager::listarClientes(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        cliente.mostrarCliente();
        if(i!=cantidad-1){
            cout<<"-----------------------------"<<endl;
        }
    }
}
void ClientesManager::buscarClienteXID(char* IDABuscar){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(cliente.getDNI()==IDABuscar){
            cliente.mostrarCliente();
        }
    }
}
