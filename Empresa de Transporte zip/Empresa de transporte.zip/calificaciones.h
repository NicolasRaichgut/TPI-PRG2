#pragma once
#include "fecha.h"
#include <string>
using namespace std;

class Calificaciones{
private:
    char idViaje[6];
    char dniCliente[8];
    char dniChofer[8];
    int puntaje;
    char comentario[120];
    bool eliminado;
public:
    Calificaciones();
    Calificaciones(string _idViaje, string _dniCliente, string _dniChofer, int _puntaje, string _comentario);
    char* getIdViaje();
    char* getIdCalificacion();
    char* getDniCliente();
    char* getDniChofer();
    int getPuntaje();
    char* getComentario();
    bool getEliminado();
    void setIdViaje(string idV);
    void setIdCalificacion(string idC);
    void setDniCliente(string dniC);
    void setDniChofer(string dniCh);
    void setPuntaje(int p);
    void setComentario(string c);
    void eliminar();
    void cargar(char* dniC,char* dniCh);
    void mostrar();
};
