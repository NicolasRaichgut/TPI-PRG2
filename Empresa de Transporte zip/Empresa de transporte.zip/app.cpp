#include <iostream>
#include "app.h"
#include "menuEmpresa.h"
using namespace std;

App::App():Menu("SISTEMA DE LA EMPRESA DE TRANSPORTE", 2){}
void App::mostrarOpciones(){

    cout<<"1. Entrar al gestor de empresa"<<endl;
    cout<<"0. Salir"<<endl;
}
void App::ejecutar(){
    int opcion;

    while(opcion!=2){
        mostrarEncabezado();
        mostrarOpciones();
        opcion=pedirOpcion();

        switch(opcion){
            case 1: {
                MenuEmpresa menu;
                menu.ejecutar();
                break;
            }
            case 0:
                break;
        }

    }
}
