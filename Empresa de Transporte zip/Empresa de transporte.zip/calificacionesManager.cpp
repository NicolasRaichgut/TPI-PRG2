#include <iostream>
#include <cstring>
#include "calificacionesManager.h"
using namespace std;

bool ViajesManager::existeCliente(char* dni){
    int cantidad=archivoClientes.contarRegistros();
    Clientes cliente;

    for(int i=0;i<cantidad;i++){
        cliente=archivoClientes.leerArchivo(i);
        if(strcmp(cliente.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}
bool ViajesManager::existeChofer(char* dni){
    int cantidad=archivoChoferes.contarRegistros();
    Choferes chofer;

    for(int i=0;i<cantidad;i++){
        chofer=archivoChoferes.leerArchivo(i);
        if(strcmp(chofer.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}
void CalificacionesManager::crearCalificacion(){
    char dniCliente[8];
    char dniChofer[8];

    cout<<"Ingrese DNI del cliente: ";
    cin>>dniCliente;
    if(!existeCliente(dniCliente)){
        cout<<"Ese DNI no corresponde a ningun cliente."<<endl;
        return;
    }
    cout<<"Ingrese DNI del chofer: ";
    cin>>dniChofer;
    if(!existeChofer(dniChofer)){
        cout<<"Ese DNI no corresponde a ningun chofer."<<endl;
        return;
    }

    calificacion.cargar(dniCliente,dniChofer);

    if(archivo.guardarArchivo(calificacion)){
        cout<<"La calificacion fue guardada correctamente."<<endl;
    }
    else{
        cout<<"No se pudo guardar la calificacion."<<endl;
    }
}
void CalificacionesManager::listarCalificaciones(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        calificacion=archivo.leerArchivo(i);
        calificacion.mostrar();
        if(i!=cantidad-1){
            cout<<"-----------------------------"<<endl;
        }
    }
}
