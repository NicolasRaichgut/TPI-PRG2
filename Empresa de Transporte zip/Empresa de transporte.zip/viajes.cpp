#include <iostream>
#include <string>
#include <cstring>
#include "viajes.h"
using namespace std;

Viajes::Viajes(){
    idViaje[0]='0';
    dniCliente[0]='0';
    dniChofer[0]='0';
    idPago[0]='0';
    eliminado=false;
}
Viajes::Viajes(string _idViaje, string _dniCliente, string _dniChofer, string _idPago, Fecha _fechaViaje){
    setIdViaje(_idViaje);
    setDniCliente(_dniCliente);
    setDniChofer(_dniChofer);
    setIdPago(_idPago);
    setFechaViaje(_fechaViaje);
    eliminado=false;
}
char* Viajes::getIdViaje(){
    return idViaje;
}
char* Viajes::getDniCliente(){
    return dniCliente;
}
char* Viajes::getDniChofer(){
    return dniChofer;
}
char* Viajes::getIdPago(){
    return idPago;
}
Fecha Viajes::getFechaViaje(){
    return fechaViaje;
}
bool Viajes::getEliminado(){
    return eliminado;
}
void Viajes::setIdViaje(string idV){
    strcpy(idViaje, idV.c_str());
}
void Viajes::setDniCliente(string dniCl){
    strcpy(dniCliente, dniCl.c_str());
}
void Viajes::setDniChofer(string dniCh){
    strcpy(dniChofer, dniCh.c_str());
}
void Viajes::setIdPago(string idP){
    strcpy(idPago, idP.c_str());
}
void Viajes::setFechaViaje(Fecha fv){
    fechaViaje=fv;
}
void Viajes::eliminar(){
    eliminado=true;
}
void Viajes::cargar(string dniCl, string dniCh){
    string idCarga;
    cout<<"Ingrese el ID del viaje (6 caracteres): ";
    cin>>idCarga;
    setIdViaje(idCarga);
    cout<<endl;
    setDniCliente(dniCl);
    setDniChofer(dniCh);
    fechaViaje.ponerFechaActual();
}
void Viajes::mostrar(){
    cout<<"ID del viaje: "<<idViaje<<endl;
    cout<<"DNI del cliente: "<<dniCliente<<endl;
    cout<<"DNI del chofer: "<<dniChofer<<endl;
    cout<<"ID del pago: "<<idPago<<endl;
    cout<<"Fecha: ";
    fechaViaje.mostrar();
    cout<<endl;
}
