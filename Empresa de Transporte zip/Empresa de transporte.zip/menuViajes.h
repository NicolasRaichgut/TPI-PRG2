#pragma once
#include "Menu.h"
#include "viajesManager.h"

class MenuViajes:public Menu{
private:
    ViajesManager manager;
public:
    MenuViajes();
    void mostrarOpciones() override;
    void ejecutar() override;
};
