#include <iostream>
#include "menuChoferes.h"
using namespace std;

MenuChoferes::MenuChoferes():Menu("MENU CHOFERES", 5) {}

void MenuChoferes::mostrarOpciones(){
    cout<<"1. Agregar chofer"<<endl;
    cout<<"2. Listar choferes"<<endl;
    cout<<"3. Buscar chofer"<<endl;
    cout<<"4. Modificar chofer"<<endl;
    cout<<"-------------------------"<<endl;
    cout<<"0. Volver"<<endl;
    cout<<"-------------------------"<<endl;
}
void MenuChoferes::ejecutar(){
    int opcion;

    do{
        mostrarEncabezado();
        mostrarOpciones();
        opcion = pedirOpcion();

        switch(opcion){
            case 1:
                manager.crearChofer();
                break;
            case 2:
                manager.listarChoferes();
                break;
            case 3:
                manager.buscarChofer();
                break;
            case 4:
                manager.modificarChofer();
                break;
            case 0:
                break;
        }
    }while(opcion!=0);
}
