#pragma once
#include "menu.h"
#include "clientesManager.h"

class MenuClientes:public Menu{
private:
    ClientesManager manager;
public:
    MenuClientes();
    void mostrarOpciones() override;
    void ejecutar() override;
};

