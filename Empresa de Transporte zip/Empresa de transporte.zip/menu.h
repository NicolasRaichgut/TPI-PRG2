#pragma once
using namespace std;

class Menu{
protected:
    char titulo[50];
    int cantidadOpciones;
public:
    Menu(const char* _titulo, int _cantidadOpciones);
    void mostrarEncabezado();
    int pedirOpcion();
    virtual void mostrarOpciones()=0;
    virtual void ejecutar()=0;
    virtual ~Menu(){}
};

