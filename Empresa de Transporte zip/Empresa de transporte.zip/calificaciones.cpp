#include <iostream>
#include <cstring>
#include "calificaciones.h"
using namespace std;

Calificaciones::Calificaciones(){
    idViaje[6]='\0';
    dniCliente[0]='\0';
    dniChofer[0]='\0';
    comentario[0]='\0';
    puntaje=0;
    eliminado=false;
}
Calificaciones::Calificaciones(string _idViaje, string _dniCliente, string _dniChofer, int _puntaje, string _comentario){
    setIdViaje(_idViaje);
    setDniCliente(_dniCliente);
    setDniChofer(_dniChofer);
    setPuntaje(_puntaje);
    setComentario(_comentario);
    eliminado=false;
}
char* Calificaciones::getIdViaje(){
    return idViaje;
}
char* Calificaciones::getDniCliente(){
    return dniCliente;
}
char* Calificaciones::getDniChofer(){
    return dniChofer;
}
int Calificaciones::getPuntaje(){
    return puntaje;
}
char* Calificaciones::getComentario(){
    return comentario;
}
bool Calificaciones::getEliminado(){
    return eliminado;
}
void Calificaciones::setIdViaje(string idV){
    strcpy(idViaje,idV.c_str());
}
void Calificaciones::setIdCalificacion(string idC){
    strcpy(idCalificacion,idC.c_str());
}
void Calificaciones::setDniCliente(string dniC){
    strcpy(dniCliente,dniC.c_str());
}
void Calificaciones::setDniChofer(string dniCh){
    strcpy(dniChofer,dniCh.c_str());
}
void Calificaciones::setPuntaje(int p){
    puntaje=p;
}
void Calificaciones::setComentario(string c){
    strcpy(comentario,c.c_str());
}
void Calificaciones::eliminar(){
    eliminado=true;
}
void Calificaciones::cargar(char* dniC,char* dniCh){
    setIdCalificacion(idC);
    setDniCliente(dniC);
    setDniChofer(dniCh);
    cout<<"Ingrese puntaje (1 a 5): ";
    cin>>puntaje;
    cout<<"Desea dejar un comentario?"<<endl;
    cout<<"1. Si"<<endl;
    cout<<"0. No"<<endl;
    int opcion;
    cin>>opcion;
    if(opcion==1){
        cout<<"Deje un comentario sobre su viaje: "<<endl;
        cin.getline(comentario,120);
    }
}
void Calificaciones::mostrar(){
    cout<<"ID calificacion: "<<idCalificacion<<endl;
    cout<<"DNI cliente: "<<dniCliente<<endl;
    cout<<"DNI chofer: "<<dniChofer<<endl;
    cout<<"Puntaje: "<<puntaje<<endl;
    cout<<"Comentario: '"<<comentario<<"'"<<endl;
}
