#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include "clientes.h"
using namespace std;

Clientes::Clientes(){
    DNI[0]='0';
    nombre[0]='N';
    apellido[0]='N';
    numTelefono[0]='0';
    email[0]='N';
    direccion[0]='N';
    Fecha f;
    fechaNacimiento=f;
}
Clientes::Clientes(string _DNI, string _nombre, string _apellido, string _numTelefono, string _email, string _direccion, Fecha _fechaNacimiento){
    setDNI(_DNI);
    setNombre(_nombre);
    setApellido(_apellido);
    setNumTelefono(_numTelefono);
    setEmail(_email);
    setDireccion(_direccion);
    setFechaNacimiento(_fechaNacimiento);
}

void Clientes::setDNI(string d){
    strcpy(DNI, d.c_str());
}
void Clientes::setNombre(string n){
    strcpy(nombre, n.c_str());
}
void Clientes::setApellido(string a){
    strcpy(apellido, a.c_str());
}
void Clientes::setNumTelefono(string t){
    strcpy(numTelefono, t.c_str());
}
void Clientes::setEmail(string e){
    strcpy(email, e.c_str());
}
void Clientes::setDireccion(string d){
    strcpy(direccion, d.c_str());
}
void Clientes::setFechaNacimiento(Fecha f){
    fechaNacimiento=f;
}

void Clientes::setEliminado(bool el){
    eliminado=el;
}

char* Clientes::getDNI() {
    return DNI;
}

char* Clientes::getNombre() {
    return nombre;
}

char* Clientes::getApellido() {
    return apellido;
}

char* Clientes::getNumTelefono() {
    return numTelefono;
}

char* Clientes::getEmail() {
    return email;
}

char* Clientes::getDireccion() {
    return direccion;
}

Fecha Clientes::getFechaNacimiento() {
    return fechaNacimiento;
}

bool Clientes::getEliminado(){
    return eliminado;
}

void Clientes::cargarCliente(){
    cout<<"Ingrese su DNI: ";
    string d;
    cin>>d;
    setDNI(d);
    cout<<endl;
    cout<<"Ingrese su nombre: ";
    string n;
    cin>>n;
    setNombre(n);
    cout<<endl;
    cout<<"Ingrese su apellido: ";
    string a;
    cin>>a;
    setApellido(a);
    cout<<endl;
    cout<<"Ingrese su numero telefonico(9/11 ****-****): ";
    string t;
    cin>>t;
    setNumTelefono(t);
    cout<<endl;
    cout<<"Ingrese su email: ";
    string e;
    cin>>e;
    setEmail(e);
    cout<<endl;
    cout<<"Ingrese su direccion: ";
    string drec;
    cin>>drec;
    setDireccion(drec);
    cout<<endl;
    cout<<"Ingrese su fecha de nacimiento: ";
    int dia;
    cin>>dia;
    cout<<"/";
    int mes;
    cin>>mes;
    cout<<"/";
    int an;
    cin>>an;
    Fecha f(dia,mes,an);
    setFechaNacimiento(f);

}

void Clientes::mostrarCliente(){
    cout<<nombre<<" "<<apellido<<endl;
    cout<<"----------------------------------------------------"<<endl;
    cout<<"DNI: "<<DNI<<endl;
    cout<<"Numero telefonico: "<<numTelefono<<endl;
    cout<<"Email: "<<email<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"Fecha de nacimiento: ";
    fechaNacimiento.mostrar();
    cout<<endl;
    cout<<"-----------------------------------------------------"<<endl;
}
