#pragma once
#include "viajes.h"

class ViajesArchivo{
private:
    const char* nombre="viajes.dat";

public:
    bool guardarArchivo(Viajes obj);
    Viajes leerArchivo(int indice);
    int contarRegistros();
};
