#pragma once
#include "choferes.h"

class ChoferesArchivo{
private:
    const char* nombre="choferes.dat";
public:
    bool guardarArchivo(Choferes obj);
    Choferes leerArchivo(int indice);
    int contarRegistros();
};
