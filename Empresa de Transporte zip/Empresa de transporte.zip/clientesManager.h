#pragma once
#include "cliantesArchivo.h"

class ClientesManager{
private:
    Clientes cliente;
    ClientesArchivo archivo;
    bool existeElID(char* ID);
public:
    void crearCliente();
    void listarClientes();
    void buscarClienteXID(char* IDABuscar);
};
