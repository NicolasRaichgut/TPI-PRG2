#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include "remises.h"
using namespace std;

Remises::Remises(){
    patente[0]='0';
    marca[0]='0';
    modelo[0]='0';
    DNIchofer[0]='0';
    capacidadPasajeros=0;
    eliminado=false;
}
Remises::Remises(string _patente, string _marca, string _modelo, string _DNIchofer, Fecha _fechaLanzamiento, int _capacidadPasajeros){
    setPatente(_patente);
    setMarca(_marca);
    setModelo(_modelo);
    setDNIchofer(_DNIchofer);
    fechaLanzamiento=_fechaLanzamiento;
    capacidadPasajeros=_capacidadPasajeros;
    eliminado=false;
}
void Remises::setPatente(string p){
    strcpy(patente, p.c_str());
}
void Remises::setMarca(string m){
    strcpy(marca, m.c_str());
}
void Remises::setModelo(string mo){
    strcpy(modelo, mo.c_str());
}
void Remises::setDNIchofer(string dni){
    strcpy(DNIchofer, dni.c_str());
}
void Remises::setFechaLanzamiento(Fecha f){
    fechaLanzamiento=f;
}
void Remises::setCapacidadPasajeros(int cp){
    capacidadPasajeros=cp;
}
void Remises::eliminar(){
    eliminado=true;
}
char* Remises::getPatente(){
    return patente;
}
char* Remises::getMarca(){
    return marca;
}
char* Remises::getModelo(){
    return modelo;
}
char* Remises::getDNIchofer(){
    return DNIchofer;
}
Fecha Remises::getFechaLanzamiento(){
    return fechaLanzamiento;
}
int Remises::getCapacidadPasajeros(){
    return capacidadPasajeros;
}
bool Remises::getEliminado(){
    return eliminado;
}
void Remises::cargar(){
    cout<<"Ingrese la patente del auto: ";
    string pI;
    cin>>pI;
    setPatente(pI);
    cout<<endl<<endl;
    cout<<"Ingrese la marca: ";
    string mI;
    cin>>mI;
    setMarca(mI);
    cout<<endl<<endl;
    cout<<"Ingrese el modelo: ";
    string moI;
    cin>>moI;
    setModelo(moI);
    cout<<endl<<endl;
    cout<<"Ingrese la fecha de lanzamiento del modelo: ";
    int dia, mes, anio;
    cin>>dia;
    cout<<"/";
    cin>>mes;
    cout<<"/";
    cin>>anio;
    Fecha fI(dia, mes, anio);
    setFechaLanzamiento(fI);
    cout<<endl<<endl;
    cout<<"Ingrese cuantos pasajeros pueden ser transportados: ";
    int cpI;
    cin>>cpI;
    setCapacidadPasajeros(cpI);
    cout<<endl<<endl;
}
void Remises::mostrar(){
    cout<<"Patente: "<<patente<<endl;
    cout<<"Marca: "<<marca<<endl;
    cout<<"Modelo: "<<modelo<<endl;
    cout<<"Fecha de lanzamiento del modelo: ";
    fechaLanzamiento.mostrar();
    cout<<endl;
    cout<<"Capacidad: "<<capacidadPasajeros<<" pasajeros"<<endl;
    cout<<"DNI del conductor: "<<DNIchofer<<endl;
}
