#pragma once
#include "remisesArchivo.h"

class RemisesManager{
private:
    Remises remis;
    RemisesArchivo archivo;
    bool existeLaPatente(char* patente);
public:
    void crearRemis();
    void listarRemises();
    void buscarRemisXPatente(char* patenteABuscar);
};
