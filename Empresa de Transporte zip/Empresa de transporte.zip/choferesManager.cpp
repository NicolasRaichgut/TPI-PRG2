#include <iostream>
#include <cstring>
#include "choferesManager.h"
using namespace std;

bool ChoferesManager::existeElID(char* ID){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(strcmp(chofer.getDNI(), ID)==0){
            return true;
        }
    }

    return false;
}
void ChoferesManager::crearChofer(){
    chofer.cargarChofer();
    system("cls");

    if(archivo.guardarArchivo(chofer)){
        cout<<"El chofer fue guardado exitosamente!"<<endl;
    }else{
        cout<<"Ups... No se pudo guardar al chofer."<<endl;
    }
}
void ChoferesManager::listarChoferes(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        chofer.mostrarChofer();
        if(i!=cantidad-1){
            cout<<"-----------------------------"<<endl;
        }
    }
}
void ChoferesManager::buscarChoferXID(char* IDABuscar){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(chofer.getDNI()==IDABuscar){
            chofer.mostrarChofer();
        }
    }
}
