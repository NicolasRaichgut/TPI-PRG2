#pragma once
#include "Menu.h"
#include "choferesManager.h"

class MenuChoferes:public Menu{
private:
    ChoferesManager manager;
public:
    MenuChoferes();
    void mostrarOpciones() override;
    void ejecutar() override;
};

