#pragma once
#include "fecha.h"
#include <string>
using namespace std;

class Pagos{
private:
    char idPago[6];
    char idViaje[6];
    int metodoPago;
    float monto;
    Fecha fechaPago;
    bool eliminado;
public:
    Pagos();
    Pagos(string _idPago, string _idViaje, int _metodoPago, float _monto, Fecha _fechaPago);
    char* getIdPago();
    char* getIdViaje();
    int getMetodoPago();
    float getMonto();
    Fecha getFechaPago();
    bool getEliminado();
    void setIdPago(string idP);
    void setIdViaje(string idV);
    void setMetodoPago(int mp);
    void setMonto(float m);
    void setFechaPago(Fecha fp);
    void eliminar();
    void cargar(char* idV);
    void mostrar();
};
