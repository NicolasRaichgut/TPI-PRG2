#include <iostream>
#include "remisesArchivo.h"
using namespace std;

bool RemisesArchivo::guardarArchivo(Remises obj){
    FILE *pR;

    pR=fopen(nombre, "ab");
    if(pR==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }
    bool archivoCargado=fwrite(&obj, sizeof obj, 1, pR);
    fclose(pR);
    return archivoCargado;
}
Remises RemisesArchivo::leerArchivo(int indice){
    FILE *pR;
    Remises remis;

    pR=fopen(nombre, "rb");
    if(pR==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return remis;
    }
    fseek(pR, indice*sizeof remis, 0);
    fread(&remis, sizeof remis, 1, pR);
    fclose(pR);
    return remis;
}
int RemisesArchivo::contarRegistros(){
    FILE *pR;
    Remises remis;

    pR=fopen(nombre, "rb");
    if(pR==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return 0;
    }
    fseek(pR, 0, SEEK_END);
    int bytes=ftell(pR);

    return bytes/sizeof remis;
}
