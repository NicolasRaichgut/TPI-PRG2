#pragma once
#include "menu.h"

class App:public Menu{
public:
    App();
    void mostrarOpciones() override;
    void ejecutar() override;
};
