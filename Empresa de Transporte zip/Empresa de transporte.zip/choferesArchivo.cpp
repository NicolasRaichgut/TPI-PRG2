#include <iostream>
#include "choferesArchivo.h"
using namespace std;

bool ChoferesArchivo::guardarArchivo(Choferes obj){
    FILE *pCh;

    pCh=fopen(nombre, "ab");
    if(pCh==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }
    bool archivoCargado=fwrite(&obj, sizeof obj, 1, pCh);
    fclose(pCh);
    return archivoCargado;
}
Choferes ChoferesArchivo::leerArchivo(int indice){
    FILE *pCh;
    Choferes chofer;

    pCh=fopen(nombre, "rb");
    if(pCh==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return chofer;
    }
    fseek(pCh, indice*sizeof chofer, 0);
    fread(&chofer, sizeof chofer, 1, pCh);
    fclose(pCh);
    return chofer;
}
int ChoferesArchivo::contarRegistros(){
    FILE *pCh;
    Choferes chofer;

    pCh=fopen(nombre, "rb");
    if(pCh==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return 0;
    }
    fseek(pCh, 0, SEEK_END);
    int bytes=ftell(pCh);

    return bytes/sizeof chofer;
}
