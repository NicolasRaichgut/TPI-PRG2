#include <iostream>
#include "menuViajes.h"
using namespace std;

MenuViajes::MenuViajes():Menu("MENU VIAJES",6) {}

void MenuViajes::mostrarOpciones(){
    cout<<"1. Crear viaje"<<endl;
    cout<<"2. Listar viajes"<<endl;
    cout<<"3. Buscar viaje"<<endl;
    cout<<"4. Cancelar viaje"<<endl;
    cout<<"5. Calificar viaje"<<endl;
    cout<<"-------------------------"<<endl;
    cout<<"0. Volver"<<endl;
    cout<<"-------------------------"<<endl;
}

void MenuViajes::ejecutar(){
    int opcion;

    do{
        mostrarEncabezado();
        mostrarOpciones();
        opcion=pedirOpcion();

        switch(opcion){
            case 1:
                manager.crearViaje();
                break;
            case 2:
                manager.listarViajes();
                break;
            case 3:
                manager.buscarViaje();
                break;
            case 4:
                manager.cancelarViaje();
                break;
            case 5:
                manager.calificarViaje();
                break;
        }
    }while(opcion!=0);
}
