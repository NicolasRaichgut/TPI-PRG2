#include <iostream>
#include "viajesArchivo.h"
using namespace std;

bool ViajesArchivo::guardarArchivo(Viajes obj){

    FILE *pV;
    pV=fopen(nombre, "ab");

    if(pV==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }

    bool archivoCargado=fwrite(&obj, sizeof obj, 1, pV);
    fclose(pV);

    return archivoCargado;
}

Viajes ViajesArchivo::leerArchivo(int indice){

    FILE *pV;
    Viajes viaje;
    pV=fopen(nombre, "rb");

    if(pV==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return viaje;
    }

    fseek(pV, indice*sizeof viaje, 0);
    fread(&viaje, sizeof viaje, 1, pV);
    fclose(pV);

    return viaje;
}

int ViajesArchivo::contarRegistros(){

    FILE *pV;
    Viajes viaje;
    pV=fopen(nombre, "rb");

    if(pV==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return 0;
    }

    fseek(pV, 0, SEEK_END);
    int bytes=ftell(pV);
    fclose(pV);

    return bytes/sizeof viaje;
}
