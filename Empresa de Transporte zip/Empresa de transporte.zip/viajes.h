#pregma once
#include "fecha.h"
using namespace std;

class Viajes{
private:
    char idViaje[6];
    char dniCliente[8];
    char dniChofer[8];
    char idPago[6];
    Fecha fechaViaje;
    bool eliminado;
public:
    Viajes();
    Viajes(string _idViaje, string _dniCliente, string _dniChofer, string _idPago, Fecha _fechaViaje);
    char* getIdViaje();
    char* getDniCliente();
    char* getDniChofer();
    char* getIdPago();
    Fecha getFechaViaje();
    bool getEliminado();
    void setIdViaje(string idV);
    void setDniCliente(string dniCl);
    void setDniChofer(string dniCh);
    void setIdPago(string idP);
    void setFechaViaje(Fecha fv);
    void eliminar();
    void cargar(char* dniCl, char* dniCh);
    void mostrar();
};
