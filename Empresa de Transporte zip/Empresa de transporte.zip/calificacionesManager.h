#pragma once
#include "calificacionesArchivo.h"
#include "clientesArchivo.h"
#include "choferesArchivo.h"

class CalificacionesManager{
private:
    Calificaciones calificacion;
    CalificacionesArchivo archivo;

    ClientesArchivo archivoClientes;
    ChoferesArchivo archivoChoferes;
public:
    void crearCalificacion();
    void listarCalificaciones();
};
