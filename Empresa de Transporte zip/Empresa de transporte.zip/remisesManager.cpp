#include <iostream>
#include <cstring>
#include "remisesManager.h"
using namespace std;

bool RemisesManager::existeLaPatente(char* patente){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(strcmp(remis.getPatente(), patente)==0){
            return true;
        }
    }

    return false;
}
void RemisesManager::crearRemis(){
    remis.cargar();
    system("cls");

    if(archivo.guardarArchivo(remis)){
        cout<<"El remis fue guardado exitosamente!"<<endl;
    }else{
        cout<<"Ups... No se pudo guardar el remis."<<endl;
    }
}
void RemisesManager::listarRemises(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        remis.mostrar();
        if(i!=cantidad-1){
            cout<<"-----------------------------"<<endl;
        }
    }
}
void RemisesManager::buscarRemisXPatente(char* patenteABuscar){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(strcmp(remis.getPatente(), patenteABuscar)==0){
            remis.mostrar();
        }
    }
}
