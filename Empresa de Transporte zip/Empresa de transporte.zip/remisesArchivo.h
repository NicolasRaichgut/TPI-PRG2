#pragma once
#include "remises.h"

class RemisesArchivo{
private:
    const char* nombre="remises.dat";
public:
    bool guardarArchivo(Remises obj);
    Remises leerArchivo(int indice);
    int contarRegistros();
};
