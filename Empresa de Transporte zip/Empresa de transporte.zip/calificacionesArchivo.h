#pragma once
#include "calificaciones.h"

class CalificacionesArchivo{
private:
    const char* nombre="calificaciones.dat";
public:
    bool guardarArchivo(Calificaciones obj);
    Calificaciones leerArchivo(int indice);
    int contarRegistros();
};
