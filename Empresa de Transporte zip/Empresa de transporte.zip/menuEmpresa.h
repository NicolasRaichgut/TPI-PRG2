#pragma once
#include "menu.h"
#include "viajesManager.h"
#include "calificacionesManager.h"

class MenuEmpresa:public Menu{
private:
    ViajesManager viajes;
    CalificacionesManager calificaciones;
public:
    MenuEmpresa();
    void mostrarOpciones() override;
    void ejecutar() override;
};

