#pragma once
#include <string>
#include "remisesArchivo.h"

class RemisesManager{
private:
    Remises remis;
    RemisesArchivo archivo;
    bool existeLaPatente(char* patente);
public:
    bool crearRemis();
    void listarRemises();
    void buscarRemisPorPatente(char* patente);
    void asignarChofer(char* patente, std::string dni);
    bool choferTieneRemis(char* dni);
    bool modificarRemis(char* patente);
    bool eliminarRemis(char* patente);
    void buscarPorChofer(char* dni);
    bool hayRemises();
};
