#include <iostream>
#include "viajesArchivo.h"
using namespace std;

bool ViajesArchivo::guardarArchivo(const Viajes& obj){
    FILE *pV;
    pV=fopen(nombre, "ab");
    if(pV==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj, sizeof obj, 1, pV);
    fclose(pV);

    return guardado
}

Viajes ViajesArchivo::leerArchivo(int indice){
    FILE *pV;
    Viajes viaje;
    pV=fopen(nombre, "rb");
    if(pV==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return viaje;
    }

    fseek(pV, indice*sizeof viaje, 0);
    if(!fread(&viaje, sizeof viaje, 1, pV)){
        cout<<"No se pudo leer el archivo."<<endl;
        fclose(pV);
        return viaje;
    }
    fclose(pV);

    return viaje;
}

int ViajesArchivo::contarRegistros(){
    FILE *pV;
    Viajes viaje;
    pV=fopen(nombre, "rb");
    if(pV==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return 0;
    }

    fseek(pV, 0, SEEK_END);
    int bytes=ftell(pV);
    fclose(pV);

    return bytes/sizeof viaje;
}


bool ViajesArchivo::sobreescribirArchivo(const Viajes& obj, int indice){
    FILE *pV;
    pV=fopen(nombre, "rb+");
    if(pV==nullptr){
        cout << "El archivo no pudo abrirse." << endl;
        return false;
    }

    fseek(pV, indice*sizeof obj, 0);
    bool escribio=fwrite(&obj, sizeof obj, 1, pV);
    fclose(pV);

    return escribio;
}

bool ViajesArchivo::bajaLogica(int indice){
    Viajes viaje;
    viaje=leerArchivo(indice);
    viaje.eliminar();
    bool registroEliminado=sobreescribirArchivo(viaje, indice);

    return registroEliminado;
}
