#pragma once
#include "pagos.h"

class PagosArchivo{
private:
    const char* nombre="pagos.dat";
public:
    bool guardarArchivo(const Pagos& obj);
    Pagos leerArchivo(int indice);
    int contarRegistros();
    bool sobreescribirArchivo(const Pagos& obj, int indice);
    bool bajaLogica(int indice);
};
