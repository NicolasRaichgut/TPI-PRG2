#pragma once
#include "clientes.h"

class ClientesArchivo{
private:
    const char* nombre="clientes.dat";
public:
    bool guardarArchivo(const Clientes& obj);
    Clientes leerArchivo(int indice);
    int contarRegistros();
    bool sobreescribirArchivo(const Clientes& obj, int indice);
    bool bajaLogica(int indice);
};
