#pragma once
#include <string>
#include "fecha.h"

class Remises{
private:
    char patente[10];
    char marca[20];
    char modelo[20];
    char DNIchofer[9];
    Fecha fechaLanzamiento;
    int capacidadPasajeros;
    bool eliminado;
public:
    Remises();
    Remises(std::string _patente, std::string _marca, std::string _modelo, std::string _DNIchofer, Fecha _fechaLanzamiento, int _capacidadPasajeros);
    void setPatente(std::string p);
    void setMarca(std::string m);
    void setModelo(std::string mo);
    void setDNIchofer(std::string dni);
    void setFechaLanzamiento(Fecha f);
    void setCapacidadPasajeros(int cp);
    void eliminar();
    const char* getPatente() const;
    const char* getMarca() const;
    const char* getModelo() const;
    const char* getDNIchofer() const;
    Fecha getFechaLanzamiento() const;
    int getCapacidadPasajeros() const;
    bool getEliminado() const;
    bool tieneChofer() const;
    void cargar();
    void mostrar();
};
