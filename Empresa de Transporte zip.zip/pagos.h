#pragma once
#include "fecha.h"
#include <string>

class Pagos{
private:
    char idPago[6];
    char idViaje[6];
    int metodoPago;
    float monto;
    Fecha fechaPago;
    bool eliminado;
public:
    Pagos();
    Pagos(std::string _idPago, std::string _idViaje, int _metodoPago, float _monto, Fecha _fechaPago);
    const char* getIdPago() const;
    const char* getIdViaje() const;
    int getMetodoPago() const;
    float getMonto() const;
    Fecha getFechaPago() const;
    bool getEliminado() const;
    void setIdPago(std::string idP);
    void setIdViaje(std::string idV);
    void setMetodoPago(int mp);
    void setMonto(float m);
    void setFechaPago(Fecha fp);
    void eliminar();
    void cargar(const char* idV);
    void mostrar();
};
