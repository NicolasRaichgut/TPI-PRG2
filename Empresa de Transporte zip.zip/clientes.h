#pragma once
#include "personas.h"

class Clientes:public Personas{
public:
    Clientes();
    Clientes(std::string _DNI, std::string _nombre, std::string _apellido, std::string _numTelefono,
    std::string _email, std::string _direccion, Fecha _fechaNacimiento);
};
