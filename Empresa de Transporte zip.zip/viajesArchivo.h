#pragma once
#include "viajes.h"

class ViajesArchivo{
private:
    const char* nombre="viajes.dat";

public:
    bool guardarArchivo(const Viajes& obj);
    Viajes leerArchivo(int indice);
    int contarRegistros();
    bool sobreescribirArchivo(const Viajes& obj, int indice);
    bool bajaLogica(int indice);
};
