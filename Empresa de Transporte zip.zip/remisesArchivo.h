#pragma once
#include "remises.h"

class RemisesArchivo{
private:
    const char* nombre="remises.dat";
public:
    bool guardarArchivo(const Remises& obj);
    Remises leerArchivo(int indice);
    int contarRegistros();
    bool sobreescribirArchivo(const Remises& obj, int indice);
    bool bajaLogica(int indice);
};
