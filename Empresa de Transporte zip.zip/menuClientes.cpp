#include <iostream>
#include "menuClientes.h"
using namespace std;

MenuClientes::MenuClientes():Menu("MENU CLIENTES",5){}

void MenuClientes::mostrarOpciones(){
    cout<<"1. Agregar cliente"<<endl;
    cout<<"2. Listar clientes"<<endl;
    cout<<"3. Buscar cliente"<<endl;
    cout<<"4. Modificar cliente"<<endl;
    cout<<"5. Eliminar cliente"<<endl;
    cout<<"-------------------------"<<endl;
    cout<<"0. Volver"<<endl;
    cout<<"-------------------------"<<endl;
}
void MenuClientes::ejecutar(){
    int opcion;

    do{
        mostrarEncabezado();
        mostrarOpciones();
        opcion = pedirOpcion();

        switch(opcion){
            case 1:
                manager.crearCliente();
                break;
            case 2:
                manager.listarClientes();
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 0:
                break;
        }

    }while(opcion!=0);
}
