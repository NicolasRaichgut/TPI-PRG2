#pragma once
#include "choferesArchivo.h"

class ChoferesManager{
private:
    Choferes chofer;
    ChoferesArchivo archivo;
    bool existeElDNI(char* dni);
public:
    void crearChofer();
    void listarChoferes();
    void buscarChoferPorDNI(char* dni);
    void modificarChofer(char* dni);
    void eliminarChofer(char* dni);
    bool hayChoferes();
};
