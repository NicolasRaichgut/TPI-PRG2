#pragma once
#include "calificacionesArchivo.h"
#include "viajes.h"

class CalificacionesManager{
private:
    Calificaciones calificacion;
    CalificacionesArchivo archivo;
public:
    bool crearCalificacion(Viajes v);
    Calificaciones buscarCalificacion(char* idViaje);
    void listarCalificaciones();
};
