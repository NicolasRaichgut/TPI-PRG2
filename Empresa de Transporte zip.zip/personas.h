#pragma once
#include <string>
#include "fecha.h"

class Personas{
protected:
    char DNI[9];
    char nombre[30];
    char apellido[30];
    char numTelefono[12];
    char email[50];
    char direccion[50];
    Fecha fechaNacimiento;
    bool eliminado;
public:
    Personas();
    Personas(std::string _DNI, std::string _nombre, std::string _apellido, std::string _numTelefono,
    std::string _email, std::string _direccion, Fecha _fechaNacimiento);
    void setDNI(std::string d);
    void setNombre(std::string n);
    void setApellido(std::string a);
    void setNumTelefono(std::string t);
    void setEmail(std::string e);
    void setDireccion(std::string d);
    void setFechaNacimiento(Fecha f);
    void eliminar();
    const char* getDNI() const;
    const char* getNombre() const;
    const char* getApellido() const;
    const char* getNumTelefono() const;
    const char* getEmail() const;
    const char* getDireccion() const;
    Fecha getFechaNacimiento() const;
    bool getEliminado() const;
    void cargar();
    void mostrar();
};
