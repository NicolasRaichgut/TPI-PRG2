#include <iostream>
#include <cstring>
#include "menuRemises.h"
#include "choferesManager.h"
using namespace std;

MenuRemises::MenuRemises():Menu("MENU REMISES", 7) {}

void MenuRemises::mostrarOpciones(){
    cout<<"1. Registrar remis"<<endl;
    cout<<"2. Listar remises"<<endl;
    cout<<"3. Buscar remis"<<endl;
    cout<<"4. Cambiar chofer asignado"<<endl;
    cout<<"5. Mostrar remis de un chofer"<<endl;
    cout<<"6. Modificar remis"<<endl;
    cout<<"7. Eliminar remis"<<endl;
    cout<<"-------------------------"<<endl;
    cout<<"0. Volver"<<endl;
    cout<<"-------------------------"<<endl;
}

void MenuRemises::ejecutar(){
    int opcion;

    do{
        mostrarEncabezado();
        mostrarOpciones();
        opcion=pedirOpcion();
        RemisesArchivo archivo;
        int cant=archivo.contarRegistros();

        switch(opcion){
        case 1:
            system("cls");
            manager.crearRemis();
            break;
        case 2:
            system("cls");
            if(cant==0){
                cout<<"Aun no se han registrado remises."<<endl;
            }
            else{
                manager.listarRemises();
            }
            break;
        case 3:{
            system("cls");
            if(cant==0){
                cout<<"Aun no se han registrado remises."<<endl;
                break;
            }
            cout<<"Ingrese la patente del remis que desea buscar: ";
            string patBusqueda;
            cin>>patBusqueda;
            char pat[11];
            strcpy(pat, patBusqueda.c_str());
            manager.buscarRemisPorPatente(pat);
            break;
        }

        case 4:{
            system("cls");
            if(cant==0){
                cout<<"Aun no se han registrado remises."<<endl;
                break;
            }
            cout<<"Ingrese la patente del remis: ";
            string patBusqueda;
            cin>>patBusqueda;
            char pat[11];
            strcpy(pat, patBusqueda.c_str());
            cout<<"Ingrese el DNI del nuevo chofer: ";
            string dniBusqueda;
            cin>>dniBusqueda;
            char dni[9];
            strcpy(dni, dniBusqueda.c_str());
            ChoferesManager managerCh;

            if(!managerCh.existeElDNI(dni)){
                cout<<"Ese DNI no pertenece a ningun chofer registrado."<<endl;
            }
            else if(manager.choferTieneRemis(dni)){
                cout<<"Ese chofer ya tiene un remis asignado."<<endl;
            }
            else{
                manager.reasignarChofer(pat, dniBusqueda);
            }
            break;
        }
        case 5:{
            system("cls");
            if(cant==0){
                cout<<"Aun no se han registrado remises."<<endl;
                break;
            }
            cout<<"Ingrese el DNI del chofer: ";
            string dniBusqueda;
            cin>>dniBusqueda;
            char dni[9];
            strcpy(dni, dniBusqueda.c_str());
            ChoferesManager managerCh;

            if(!managerCh.existeElDNI(dni)){
                cout<<"Ese DNI no pertenece a ningun chofer registrado."<<endl;
            }
            else{
                manager.buscarPorChofer(dni);
            }
            break;
        }

        case 6:{
            system("cls");
            if(cant==0){
                cout<<"Aun no se han registrado remises."<<endl;
                break;
            }
            cout<<"Ingrese la patente del remis que desea modificar: ";
            string patBusqueda;
            cin>>patBusqueda;
            char pat[11];
            strcpy(pat, patBusqueda.c_str());
            manager.modificarRemis(pat);
            break;
        }
        case 7:{
            system("cls");
            if(cant==0){
                cout<<"Aun no se han registrado remises."<<endl;
                break;
            }
            cout<<"Ingrese la patente del remis que desea eliminar: ";
            string patBusqueda;
            cin>>patBusqueda;
            char pat[11];
            strcpy(pat, patBusqueda.c_str());
            manager.eliminarRemis(pat);
            break;
        }
        case 0:
            break;
    }while(opcion!=0);
}
