#pragma once
#include "menu.h"
#include "remisesManager.h"

class MenuRemises:public Menu{
private:
    RemisesManager manager;
public:
    MenuRemises();
    void mostrarOpciones() override;
    void ejecutar() override;
};
