#include <iostream>
#include "remisesArchivo.h"
using namespace std;

bool RemisesArchivo::guardarArchivo(const Remises& obj){
    FILE *pR;
    pR=fopen(nombre, "ab");
    if(pR==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj, sizeof obj, 1, pR);
    fclose(pR);

    return guardado;
}
Remises RemisesArchivo::leerArchivo(int indice){
    FILE *pR;
    Remises remis;
    pR=fopen(nombre, "rb");
    if(pR==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return remis;
    }

    fseek(pR, indice*sizeof remis, 0);
    if(!fread(&remis, sizeof remis, 1, pR)){
        cout<<"El archivo no pudo leerse."<<endl;
        fclose(pR);
        return remis;
    }
    fclose(pR);

    return remis;
}

int RemisesArchivo::contarRegistros(){
    FILE *pR;
    Remises remis;
    pR=fopen(nombre, "rb");
    if(pR==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return 0;
    }

    fseek(pR, 0, SEEK_END);
    int bytes=ftell(pR);
    fclose(pR);

    return bytes/sizeof remis;
}

bool RemisesArchivo::sobreescribirArchivo(const Remises& obj, int indice){
    FILE *pR;
    pR=fopen(nombre, "rb+");
    if(pR==nullptr){
        cout << "El archivo no pudo abrirse." << endl;
        return false;
    }

    fseek(pR, indice*sizeof obj, 0);
    bool escribio=fwrite(&obj, sizeof obj, 1, pR);
    fclose(pR);

    return escribio;
}

bool RemisesArchivo::bajaLogica(int indice){
    Remises remis;
    remis=leerArchivo(indice);
    remis.eliminar();
    bool registroEliminado=sobreescribirArchivo(remis, indice);

    return registroEliminado;
}
