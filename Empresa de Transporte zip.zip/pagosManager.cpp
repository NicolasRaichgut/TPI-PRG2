#include <iostream>
#include <cstring>
#include "pagosManager.h"
using namespace std;

bool PagosManager::crearPago(const char* idV){
    pago.cargar(idV);

    if(archivo.guardarArchivo(pago)){
        cout<<"Pago guardado correctamente!"<<endl;
        return true;
    }
    else{
        cout<<"Ups... no se pudo guardar el pago."<<endl;
    }

    return false;
}
Pagos PagosManager::buscarPago(const char* idV){
    int cantidad=archivo.contarRegistros();
    Pagos pagoPorDefecto;

    for(int i=0;i<cantidad;i++){
        pago=archivo.leerArchivo(i);
        if(!pago.getEliminado() && strcmp(pago.getIdViaje(), idV)==0){
            return pago;
        }
    }

    return pagoPorDefecto;
}
void PagosManager::listarPagos(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        pago=archivo.leerArchivo(i);
        if(!pago.getEliminado()){
            pago.mostrar();
            if(i!=cantidad-1){
                cout<<"---------------------------"<<endl;
            }
        }
    }
}
