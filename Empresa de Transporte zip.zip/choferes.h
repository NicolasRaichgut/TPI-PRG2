#pragma once
#include "personas.h"

class Choferes:public Personas{
public:
    Choferes();
    Choferes(std::string _DNI, std::string _nombre, std::string _apellido, std::string _numTelefono,
    std::string _email, std::string _direccion, Fecha _fechaNacimiento);
};
