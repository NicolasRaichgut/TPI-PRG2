#include <iostream>
#include <cstring>
#include "calificaciones.h"
using namespace std;

Calificaciones::Calificaciones(){
    idViaje[0]='\0';
    comentario[0]='\0';
    puntaje=0;
    eliminado=false;
}
Calificaciones::Calificaciones(string _idViaje, int _puntaje, string _comentario){
    setIdViaje(_idViaje);
    setPuntaje(_puntaje);
    setComentario(_comentario);
    eliminado=false;
}
const char* Calificaciones::getIdViaje() const{
    return idViaje;
}

int Calificaciones::getPuntaje() const{
    return puntaje;
}
const char* Calificaciones::getComentario() const{
    return comentario;
}
bool Calificaciones::getEliminado() const{
    return eliminado;
}
void Calificaciones::setIdViaje(string idV){
    strcpy(idViaje,idV.c_str());
}

void Calificaciones::setPuntaje(int p){
    puntaje=p;
}
void Calificaciones::setComentario(string c){
    strcpy(comentario,c.c_str());
}
void Calificaciones::eliminar(){
    eliminado=true;
}
void Calificaciones::cargar(char* idV){
    setIdViaje(idV);
    cout<<"Ingrese puntaje (1 a 5): ";
    int p;
    cin>>p;
    setPuntaje(p);
    cout<<"Desea dejar un comentario?"<<endl;
    cout<<"1. Si"<<endl;
    cout<<"0. No"<<endl;
    int opcion;
    cin>>opcion;
    cin.ignore();
    if(opcion==1){
        cout<<"Deje un comentario sobre su viaje: "<<endl;
        string texto;
        getline(cin,texto);
        setComentario(texto);
    }else{
        comentario[0]='\0';
    }
}
void Calificaciones::mostrar(){
    cout<<"ID viaje: "<<idViaje<<endl;
    cout<<"Puntaje: "<<puntaje<<"/5"<<endl;
    cout<<"Comentario: ";
    if(comentario[0]=='\0'){
        cout<<"Este viaje no recibio un comentario."<<endl;
    }else{
        cout<<"'"<<comentario<<"'."<<endl;
    }
}
