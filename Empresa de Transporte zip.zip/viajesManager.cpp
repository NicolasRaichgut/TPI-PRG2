#include <iostream>
#include <cstring>
#include "viajesManager.h"
#include "pagosManager.h"
#include "calificacionesManager.h"
using namespace std;

bool ViajesManager::existeCliente(char* dni){
    int cantidad=archivoClientes.contarRegistros();
    Clientes cliente;

    for(int i=0;i<cantidad;i++){
        cliente=archivoClientes.leerArchivo(i);
        if(strcmp(cliente.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}
bool ViajesManager::existeChofer(char* dni){
    int cantidad=archivoChoferes.contarRegistros();
    Choferes chofer;

    for(int i=0;i<cantidad;i++){
        chofer=archivoChoferes.leerArchivo(i);
        if(strcmp(chofer.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}

bool ViajesManager::existeViaje(char* idV){
    int cantidad=archivoChoferes.contarRegistros();

    for(int i=0;i<cantidad;i++){
        viaje=archivo.leerArchivo(i);
        if(strcmp(viaje.getIdViaje(), idV)==0){
            return true;
        }
    }

    return false;
}
bool ViajesManager::crearViaje(){
    char dniCliente[8];
    char dniChofer[8];
    PagosManager managerP;
    CalificacionesManager managerC;

    cout<<"Ingrese el DNI del cliente: ";
    cin>>dniCliente;
    if(!existeCliente(dniCliente)){
        cout<<"Ese DNI no corresponde a ningun cliente."<<endl;
        return false;
    }

    cout<<"Ingrese el DNI del chofer: ";
    cin>>dniChofer;
    if(!existeChofer(dniChofer)){
        cout<<"Ese DNI no corresponde a ningun chofer."<<endl;
        return false;
    }

    viaje.cargar(dniCliente, dniChofer);
    if(!archivo.guardarArchivo(viaje)){
        cout<<"Ups... No se pudo guardar el viaje."<<endl;
        return false;
    }
    if(!managerP.crearPago(viaje.getIdViaje())){
        cout<<"Ups... No se pudo guardar el pago."<<endl;
        return false;
    }
    if(!managerC.crearCalificacion(viaje.getIdViaje())){
        cout<<"Ups... No se pudo guardar la calificacion."<<endl;
        return false;
    }
    system("cls");

    cout<<"El viaje, junto a su pago y calificacion fueron guardados exitosamente!"<<endl;

    return true;
}

void ViajesManager::listarViajes(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        viaje=archivo.leerArchivo(i);
        viaje.mostrar();
        if(i!=cantidad-1){
            cout<<"-----------------------------"<<endl;
        }
    }
}

void ViajesManager::buscarViajeXId(char* idABuscar){

    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        viaje=archivo.leerArchivo(i);
        if(strcmp(viaje.getIdViaje(), idABuscar)==0){
                viaje.mostrar();
        }
    }
}
