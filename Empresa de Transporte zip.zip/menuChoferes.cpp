#include <iostream>
#include "menuChoferes.h"
using namespace std;

MenuChoferes::MenuChoferes():Menu("MENU CHOFERES", 6) {}

void MenuChoferes::mostrarOpciones(){
    cout<<"1. Agregar chofer"<<endl;
    cout<<"2. Listar choferes"<<endl;
    cout<<"3. Buscar chofer"<<endl;
    cout<<"4. Modificar chofer"<<endl;
    cout<<"5. Eliminar chofer"<<endl;
    cout<<"6. Gestor de Remises"<<endl;
    cout<<"-------------------------"<<endl;
    cout<<"0. Volver"<<endl;
    cout<<"-------------------------"<<endl;
}
void MenuChoferes::ejecutar(){
    int opcion;

    do{
        mostrarEncabezado();
        mostrarOpciones();
        opcion=pedirOpcion();

        switch(opcion){
            case 1:
                manager.crearChofer();
                break;
            case 2:
                manager.listarChoferes();
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 0:
                break;
        }
    }while(opcion!=0);
}
