#pragma once
#include "choferes.h"

class ChoferesArchivo{
private:
    const char* nombre="choferes.dat";
public:
    bool guardarArchivo(const Choferes& obj);
    Choferes leerArchivo(int indice);
    int contarRegistros();
    bool sobreescribirArchivo(const Choferes& obj, int indice);
    bool bajaLogica(int indice);
};
