#pragma once
#include "pagosArchivo.h"

class PagosManager{
private:
    Pagos pago;
    PagosArchivo archivo;
public:
    bool crearPago(const char* idV);
    Pagos buscarPago(const char* idV);
    void listarPagos();
};
