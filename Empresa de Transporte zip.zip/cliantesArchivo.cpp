#include <iostream>
#include "clientesArchivo.h"
using namespace std;

bool ClientesArchivo::guardarArchivo(const Clientes& obj){
    FILE *pCl;
    pCl=fopen(nombre, "ab");
    if(pCl==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj, sizeof obj, 1, pCl);
    fclose(pCl);

    return guardado;
}
Clientes ClientesArchivo::leerArchivo(int indice){
    FILE *pCl;
    Clientes cliente;

    pCl=fopen(nombre, "rb");
    if(pCl==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return cliente;
    }
    fseek(pCl, indice*sizeof cliente, 0);
    if(!fread(&cliente, sizeof cliente, 1, pCl)){
        cout<<"El archivo no pudo leerse."<<endl;
        fclose(pCl);
        return cliente;
    }
    fclose(pCl);
    return cliente;
}
int ClientesArchivo::contarRegistros(){
    FILE *pCl;
    Clientes cliente;

    pCl=fopen(nombre, "rb");
    if(pCl==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return 0;
    }
    fseek(pCl, 0, SEEK_END);
    int bytes=ftell(pCl);
    fclose(pCl);

    return bytes/sizeof cliente;
}

bool ClientesArchivo::sobreescribirArchivo(const Clientes& obj, int indice){
    FILE *pCl;
    pCl=fopen(nombre, "rb+");
    if(pCl==nullptr){
        cout << "El archivo no pudo abrirse." << endl;
        return false;
    }

    fseek(pCl, indice*sizeof obj, 0);
    bool escribio=fwrite(&obj, sizeof obj, 1, pCl);
    fclose(pCl);

    return escribio;
}

bool ClientesArchivo::bajaLogica(int indice){
    Clientes cliente;
    cliente=leerArchivo(indice);
    cliente.eliminar();
    bool registroEliminado=sobreescribirArchivo(cliente, indice);

    return registroEliminado;
}
