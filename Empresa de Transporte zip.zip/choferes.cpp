#include "choferes.h"
using namespace std;

Choferes::Choferes():Personas(){}

Choferes::Choferes(string _DNI, string _nombre, string _apellido, string _numTelefono,
                   string _email, string _direccion, Fecha _fechaNacimiento):
                       Personas(_DNI, _nombre, _apellido, _numTelefono, _email, _direccion, _fechaNacimiento){}
