#pragma once
#include "viajesArchivo.h"
#include "clientesArchivo.h"
#include "choferesArchivo.h"

class ViajesManager{
private:
    Viajes viaje;
    ViajesArchivo archivo;
    ClientesArchivo archivoClientes;
    ChoferesArchivo archivoChoferes;
    bool existeCliente(char* dni);
    bool existeChofer(char* dni);
    bool existeViaje(char* idV);
public:
    bool crearViaje();
    void listarViajes();
    void buscarViajeXId(char* idABuscar);
};
