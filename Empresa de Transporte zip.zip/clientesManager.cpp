#include <iostream>
#include <cstring>
#include "clientesManager.h"
using namespace std;

bool ClientesManager::existeElDNI(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(!cliente.getEliminado() && strcmp(cliente.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}
void ClientesManager::crearCliente(){
    cliente.cargar();
    if(existeElDNI(cliente.getDNI())){
        cout<<"Ya existe un cliente con ese DNI."<<endl;
        return;
    }
    system("cls");

    if(archivo.guardarArchivo(cliente)){
        cout<<"El cliente fue guardado exitosamente!"<<endl;
    }else{
        cout<<"Ups... No se pudo guardar al cliente."<<endl;
    }
}

void ClientesManager::listarClientes(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(!cliente.getEliminado()){
            cliente.mostrar();
            if(i!=cantidad-1){
                cout<<"-----------------------------"<<endl;
            }
        }
    }
}
void ClientesManager::buscarClientePorDNI(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(!cliente.getEliminado() && strcmp(cliente.getDNI(), dni)==0){
            cliente.mostrar();
        }
    }
}

void ClientesManager::modificarCliente(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(!cliente.getEliminado() && strcmp(cliente.getDNI(), dni)==0){
            cliente.mostrar();
            cout<<"Esta seguro de que desea modificar el registro? [1-Si/0-No]"<<endl;
            int opcion;
            cin>>opcion;
            if(opcion==1){
                system("cls");
                cout<<"Datos antiguos: "<<endl;
                cout<<"---------------------------------------"<<endl;
                cliente.mostrar();
                cout<<"---------------------------------------"<<endl;
                cout<<"Nuevos datos: "<<endl;
                cout<<"---------------------------------------"<<endl;
                cliente.cargar();

                system("cls");
                if(archivo.sobreescribirArchivo(cliente, i)){
                    cliente.mostrar();
                    cout<<"---------------------------------------"<<endl;
                    cout<<"Estos datos fueron ingresados con exito!"<<endl;
                }else{
                    cout<<"No se pudieron cargar los nuevos datos"<<endl;
                }
            }
        }
    }
}

void ClientesManager::eliminarCliente(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        cliente=archivo.leerArchivo(i);
        if(!cliente.getEliminado() && strcmp(cliente.getDNI(), dni)==0){
            if(archivo.bajaLogica(i)){
                system("cls");
                cout<<"Cliente eliminado correctamente."<<endl;
                return;
            }else{
                system("cls");
                cout<<"No se pudo eliminar el cliente."<<endl;
                return;
            }
        }
    }
}

bool ClientesManager::hayClientes(){
    return archivo.contarRegistros()>0;
}

