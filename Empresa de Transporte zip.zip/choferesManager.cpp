#include <iostream>
#include <cstring>
#include "choferesManager.h"
using namespace std;

bool ChoferesManager::existeElDNI(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(!chofer.getEliminado() && strcmp(chofer.getDNI(), dni)==0){
            return true;
        }
    }

    return false;
}
void ChoferesManager::crearChofer(){
    chofer.cargar();
    if(existeElDNI(chofer.getDNI())){
        cout<<"Ya existe un chofer con ese DNI."<<endl;
        return;
    }
    system("cls");

    if(archivo.guardarArchivo(chofer)){
        cout<<"El chofer fue guardado exitosamente!"<<endl;
    }else{
        cout<<"Ups... No se pudo guardar al chofer."<<endl;
    }
}
void ChoferesManager::listarChoferes(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(!chofer.getEliminado()){
            chofer.mostrar();
            if(i!=cantidad-1){
                cout<<"-----------------------------"<<endl;
            }
        }
    }
}
void ChoferesManager::buscarChoferPorDNI(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(!chofer.getEliminado() && strcmp(chofer.getDNI(), dni)==0){
            chofer.mostrar();
        }
    }
}

void ChoferesManager::modificarChofer(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(!chofer.getEliminado() && strcmp(chofer.getDNI(), dni)==0){
            chofer.mostrar();
            cout<<"Esta seguro de que desea modificar el registro? [1-Si/0-No]"<<endl;
            int opcion;
            cin>>opcion;
            if(opcion==1){
                system("cls");
                cout<<"Datos antiguos: "<<endl;
                cout<<"---------------------------------------"<<endl;
                chofer.mostrar();
                cout<<"---------------------------------------"<<endl;
                cout<<"Nuevos datos: "<<endl;
                cout<<"---------------------------------------"<<endl;
                chofer.cargar();

                system("cls");
                if(archivo.sobreescribirArchivo(chofer, i)){
                    chofer.mostrar();
                    cout<<"---------------------------------------"<<endl;
                    cout<<"Estos datos fueron ingresados con exito!"<<endl;
                }else{
                    cout<<"No se pudieron cargar los nuevos datos"<<endl;
                }
            }
        }
    }
}

void ChoferesManager::eliminarChofer(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        chofer=archivo.leerArchivo(i);
        if(!chofer.getEliminado() && strcmp(chofer.getDNI(), dni)==0){
            if(archivo.bajaLogica(i)){
                system("cls");
                cout<<"Chofer eliminado correctamente."<<endl;
                return;
            }else{
                system("cls");
                cout<<"No se pudo eliminar el chofer."<<endl;
                return;
            }
        }
    }
}

bool ChoferesManager::hayChoferes(){
    return archivo.contarRegistros()>0;
}
