#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include "personas.h"
using namespace std;

Personas::Personas(){
    DNI[0]='\0';
    nombre[0]='\0';
    apellido[0]='\0';
    numTelefono[0]='\0';
    email[0]='\0';
    direccion[0]='\0';
    eliminado=false;
}
Personas::Personas(string _DNI, string _nombre, string _apellido, string _numTelefono,
                   string _email, string _direccion, Fecha _fechaNacimiento){
    setDNI(_DNI);
    setNombre(_nombre);
    setApellido(_apellido);
    setNumTelefono(_numTelefono);
    setEmail(_email);
    setDireccion(_direccion);
    setFechaNacimiento(_fechaNacimiento);
    eliminado=false;
}

void Personas::setDNI(string d){
    strcpy(DNI, d.c_str());
}
void Personas::setNombre(string n){
    strcpy(nombre, n.c_str());
}
void Personas::setApellido(string a){
    strcpy(apellido, a.c_str());
}
void Personas::setNumTelefono(string t){
    strcpy(numTelefono, t.c_str());
}
void Personas::setEmail(string e){
    strcpy(email, e.c_str());
}
void Personas::setDireccion(string d){
    strcpy(direccion, d.c_str());
}
void Personas::setFechaNacimiento(Fecha f){
    fechaNacimiento=f;
}
void Personas::eliminar(){
    eliminado=true;
}
const char* Personas::getDNI() const{
    return DNI;
}
const char* Personas::getNombre() const{
    return nombre;
}
const char* Personas::getApellido() const{
    return apellido;
}
const char* Personas::getNumTelefono() const{
    return numTelefono;
}
const char* Personas::getEmail() const{
    return email;
}
const char* Personas::getDireccion() const{
    return direccion;
}
Fecha Personas::getFechaNacimiento() const{
    return fechaNacimiento;
}
bool Personas::getEliminado() const{
    return eliminado;
}
void Personas::cargar(){
    string d, n, a, t, e, drec;
    int dia, mes, anio;
    cout<<"Ingrese el DNI: ";
    cin>>d;
    setDNI(d);
    cin.ignore();
    cout<<"Ingrese el nombre: ";
    getline(cin, n);
    setNombre(n);
    cout<<"Ingrese el apellido: ";
    getline(cin, a);
    setApellido(a);
    cout<<"Ingrese el numero telefonico (9/11 ****-****): ";
    getline(cin, t);
    setNumTelefono(t);
    cout<<"Ingrese el email: ";
    getline(cin, e);
    setEmail(e);
    cout<<"Ingrese la direccion: ";
    getline(cin, drec);
    setDireccion(drec);
    cout<<"Ingrese la fecha de nacimiento: ";
    cin>>dia;
    cout<<"/";
    cin>>mes;
    cout<<"/";
    cin>>anio;
    Fecha f(dia,mes,anio);
    setFechaNacimiento(f);

}
void Personas::mostrar(){
    cout<<nombre<<" "<<apellido<<endl;
    cout<<"---------------------------------------"<<endl;
    cout<<"DNI: "<<DNI<<endl;
    cout<<"Numero telefonico: "<<numTelefono<<endl;
    cout<<"Email: "<<email<<endl;
    cout<<"Direccion: "<<direccion<<endl;
    cout<<"Fecha de nacimiento: ";
    fechaNacimiento.mostrar();
    cout<<endl;
}
