#include <iostream>
#include <cstring>
#include "remisesManager.h"
using namespace std;

bool RemisesManager::existeLaPatente(char* patente){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() && strcmp(remis.getPatente(), patente)==0){
            return true;
        }
    }

    return false;
}
bool RemisesManager::crearRemis(){
    remis.cargar();
    if(existeLaPatente(remis.getPatente())){
            system("cls")
        cout<<"Ya existe un remis con esa patente."<<endl;
        return false;
    }
    if(archivo.guardarArchivo(remis)){
        system("cls");
        cout<<"El remis fue guardado exitosamente!"<<endl;
        return true;
    }else{
        system("cls")
        cout<<"Ups... No se pudo guardar el remis."<<endl;
    }

    return false;
}
void RemisesManager::listarRemises(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado()){
            remis.mostrar();
            if(i!=cantidad-1){
                cout<<"-----------------------------"<<endl;
            }
        }
    }
}
void RemisesManager::buscarRemisPorPatente(char* patente){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() &&
           strcmp(remis.getPatente(), patente)==0){
            remis.mostrar();
            return;
        }
    }
}
void RemisesManager::asignarChofer(char* patente, string dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        Remises remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() && strcmp(remis.getPatente(), patente)==0){
            remis.setDNIchofer(dni);
            if(archivo.sobreescribirArchivo(remis,i)){
                cout<<"Ademas, el chofer asignado correctamente."<<endl;
                return;
            }
        }
    }

    cout<<"Excelente, pero no se pudo asignar el chofer."<<endl;
}
bool RemisesManager::choferTieneRemis(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0; i<cantidad; i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() && strcmp(remis.getDNIchofer(), dni)==0){
            return true;
        }
    }
    return false;
}
bool RemisesManager::modificarRemis(char* patente){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() && strcmp(remis.getPatente(), patente)==0){
            cout<<"Ingrese los nuevos datos:"<<endl;
            string dniChofer=remis.getDNIchofer();
            remis.cargar();
            remis.setDNIchofer(dniChofer);
            if(archivo.sobreescribirArchivo(remis, i)){
                cout<<"Remis modificado correctamente."<<endl;
                return true;
            }
        }
    }

    cout<<"No se pudo modificar el remis."<<endl;
    return false;
}
bool RemisesManager::eliminarRemis(char* patente){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() && strcmp(remis.getPatente(),patente)==0){
            remis.eliminar();
            if(archivo.sobreescribirArchivo(remis, i)){
                cout<<"Remis eliminado correctamente."<<endl;
                return true;
            }
        }

    }

    cout<<"No se pudo eliminar el remis."<<endl;

    return false;
}
void RemisesManager::buscarPorChofer(char* dni){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        remis=archivo.leerArchivo(i);
        if(!remis.getEliminado() && strcmp(remis.getDNIchofer(), dni)==0){
            remis.mostrar();
        }
    }
}
bool RemisesManager::hayRemises(){
    return archivo.contarRegistros()>0;
}
