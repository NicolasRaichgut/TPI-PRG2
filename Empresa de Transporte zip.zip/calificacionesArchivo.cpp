#include <iostream>
#include "calificacionesArchivo.h"
using namespace std;

bool CalificacionesArchivo::guardarArchivo(const Calificaciones& obj){
    FILE *pC;
    pC=fopen(nombre,"ab");
    if(pC==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj, sizeof obj , 1, pC);
    fclose(pC);

    return guardado;
}

Calificaciones CalificacionesArchivo::leerArchivo(int indice){
    FILE *pC;
    Calificaciones calificacion;
    pC=fopen(nombre,"rb");
    if(pC==nullptr){
        cout<<"No se pudo abrir el archivo."<<endl;
        return calificacion;
    }

    fseek(pC,indice*sizeof calificacion,0);
    if(!fread(&calificacion,sizeof calificacion,1,pC)){
        cout<<"No se pudo leer el archivo."<<endl;
        fclose(pC);
        return calificacion;
    }
    fclose(pC);

    return calificacion;
}

int CalificacionesArchivo::contarRegistros(){
    FILE *pC;
    Calificaciones calificacion;
    pC=fopen(nombre,"rb");
    if(pC==nullptr){
        return 0;
    }

    fseek(pC,0,SEEK_END);
    int bytes=ftell(pC);
    fclose(pC);

    return bytes/sizeof calificacion;
}

bool CalificacionesArchivo::sobreescribirArchivo(const Calificaciones& obj, int indice){
    FILE *pCa;
    pCa=fopen(nombre, "rb+");
    if(pCa==nullptr){
        cout<<"El archivo no pudo abrirse."<<endl;
        return false;
    }

    fseek(pCa, indice*sizeof obj, 0);
    bool escribio=fwrite(&obj, sizeof obj, 1, pCa);
    fclose(pCa);

    return escribio;
}
bool CalificacionesArchivo::bajaLogica(int indice){
    Calificaciones calificacion;
    calificacion=leerArchivo(indice);
    calificacion.eliminar();
    bool registroEliminado=sobreescribirArchivo(calificacion, indice);

    return registroEliminado;
}
