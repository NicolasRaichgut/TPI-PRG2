#include <iostream>
#include <cstring>
#include "calificacionesManager.h"
using namespace std;

bool CalificacionesManager::crearCalificacion(Viajes v){
    calificacion.cargar(v.getIdViaje());

    if(archivo.guardarArchivo(calificacion)){
        cout<<"La calificacion fue guardada correctamente."<<endl;
        return true;
    }
    else{
        cout<<"No se pudo guardar la calificacion."<<endl;
    }

    return false;
}
Calificaciones CalificacionesManager::buscarCalificacion(char* idViaje){
    int cantidad=archivo.contarRegistros();
    Calificaciones calificacionPorDefecto;

    for(int i=0;i<cantidad;i++){
        calificacion=archivo.leerArchivo(i);
        if(!calificacion.getEliminado() && strcmp(calificacion.getIdViaje(),idViaje)==0){
            return calificacion;
        }
    }

    return calificacionPorDefecto;
}
void CalificacionesManager::listarCalificaciones(){
    int cantidad=archivo.contarRegistros();

    for(int i=0;i<cantidad;i++){
        calificacion=archivo.leerArchivo(i);
        if(!calificacion.getEliminado()){
            calificacion.mostrar();
            if(i!=cantidad-1){
                cout<<"-----------------------------"<<endl;
            }
        }
    }
}
