#include <iostream>
#include "pagosArchivo.h"
using namespace std;

bool PagosArchivo::guardarArchivo(const Pagos& obj){
    FILE *pP;
    pP=fopen(nombre,"ab");
    if(pP==nullptr){
        cout<<"El archivo no pudo crearse."<<endl;
        return false;
    }

    bool guardado=fwrite(&obj, sizeof obj, 1, pP);
    fclose(pP);

    return guardado;
}

Pagos PagosArchivo::leerArchivo(int indice){
    FILE *pP;
    Pagos pago;
    pP=fopen(nombre,"rb");

    if(pP==nullptr){
        cout<<"No se pudo abrir el archivo."<<endl;
        return pago;
    }

    fseek(pP,indice*sizeof pago,0);
    if(!fread(&pago,sizeof pago,1,pP)){
        cout<<"No se pudo leer el registro."<<endl;
        return pago;
    }
    fclose(pP);

    return pago;
}

int PagosArchivo::contarRegistros(){
    FILE *pP;
    Pagos pago;
    pP=fopen(nombre,"rb");

    if(pP==nullptr){
        return 0;
    }

    fseek(pP,0,SEEK_END);
    int bytes=ftell(pP);
    fclose(pP);

    return bytes/sizeof pago;
}


bool PagosArchivo::sobreescribirArchivo(const Pagos& obj, int indice){
    FILE *pP;
    pP=fopen(nombre, "rb+");
    if(pP==nullptr){
        cout << "El archivo no pudo abrirse." << endl;
        return false;
    }

    fseek(pP, indice*sizeof obj, 0);
    bool escribio=fwrite(&obj, sizeof obj, 1, pP);
    fclose(pP);

    return escribio;
}

bool PagosArchivo::bajaLogica(int indice){
    Pagos pago;
    pago=leerArchivo(indice);
    pago.eliminar();
    bool registroEliminado=sobreescribirArchivo(pago, indice);

    return registroEliminado;
}
