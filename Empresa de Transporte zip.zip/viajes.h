#pragma once
#include "fecha.h"
#include <string>

class Viajes{
private:
    char idViaje[6];
    char dniCliente[8];
    char dniChofer[8];
    Fecha fechaViaje;
    bool eliminado;
public:
    Viajes();
    Viajes(std::string _idViaje, std::string _dniCliente, std::string _dniChofer, Fecha _fechaViaje);
    char* getIdViaje();
    char* getDniCliente();
    char* getDniChofer();
    Fecha getFechaViaje();
    bool getEliminado();
    void setIdViaje(std::string id);
    void setDniCliente(std::string dni);
    void setDniChofer(std::string dni);
    void setFechaViaje(Fecha fv);
    void eliminar();
    void cargar(std::string dniCl, std::string dniCh);
    void mostrar();
};
