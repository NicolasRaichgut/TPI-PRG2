#pragma once
#include "cliantesArchivo.h"

class ClientesManager{
private:
    Clientes cliente;
    ClientesArchivo archivo;
    bool existeElDNI(char* dni);
public:
    void crearCliente();
    void listarClientes();
    void buscarClientePorDNI(char* dni);
    void modificarCliente(char* dni);
    void eliminarCliente(char* dni);
    bool hayClientes();
};
