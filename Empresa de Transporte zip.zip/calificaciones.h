#pragma once
#include <string>

class Calificaciones{
private:
    char idViaje[6];
    int puntaje;
    char comentario[120];
    bool eliminado;
public:
    Calificaciones();
    Calificaciones(std::string _idViaje, int _puntaje, std::string _comentario);
    const char* getIdViaje() const;
    int getPuntaje() const;
    const char* getComentario() const;
    bool getEliminado() const;
    void setIdViaje(std::string idV);
    void setPuntaje(int p);
    void setComentario(std::string c);
    void eliminar();
    void cargar(char* idV);
    void mostrar();
};
